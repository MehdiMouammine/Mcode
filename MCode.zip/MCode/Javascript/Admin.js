  function out() {
    $("#out").css('color', '#C0C0C0')
  }
  function lout() {
    $("#out").css('color', 'black')
  }
$(document).ready(function(){
    $("#hnpr").click(function(){$("#npr").slideToggle(2000);});
    $("#hdpr").click(function(){$("#dpr").slideToggle(2000);});
    $("#hnsr").click(function(){$("#nsr").slideToggle(2000);});
    $("#hnsk").click(function(){$("#nsk").slideToggle(2000);});
    $("#hned").click(function(){$("#ned").slideToggle(2000);});
    $("#hnla").click(function(){$("#nla").slideToggle(2000);});
    $("#hdsr").click(function(){$("#dsr").slideToggle(2000);});
    $("#hdsk").click(function(){$("#dsk").slideToggle(2000);});
    $("#hded").click(function(){$("#ded").slideToggle(2000);});
    $("#hdla").click(function(){$("#dla").slideToggle(2000);});
    $("#huim").click(function(){$("#uim").slideToggle(2000);});
    $("#huus").click(function(){$("#uus").slideToggle(2000);});
});
